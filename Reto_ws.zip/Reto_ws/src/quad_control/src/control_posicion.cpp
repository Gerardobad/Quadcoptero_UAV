// Header files que llaman a las librerías de C++, ROS y ROS Messages.
#include <ros/ros.h>
#include <std_msgs/String.h>
#include <std_msgs/Float64.h>
#include <std_msgs/UInt64.h>
#include <geometry_msgs/Vector3.h>
#include <vector>
#include <quad_control/Pose2D.h>
#include <geometry_msgs/Pose2D.h>
#include <iostream>
#include <cmath>
#include <string>
#include <eigen3/Eigen/Dense>
#include <geometry_msgs/Twist.h> 


    float x, x_des, y, y_des, z, z_des;
    float x_vel, x_vel_des, y_vel, y_vel_des, z_vel, z_vel_des;


    float Th;
    int m = 2;
    float g = 9.81;

    float phi;
    float theta; //pitch 
    float psi; //yaw
    //float delta_z;
    // float z_dotdot = 0;

    float kp_x = 0.1;
    float kd_x = 0.8;
    float kp_y = 0.1;
    float kd_y = 0.8;
    float kp_z = 3.8;
    float kd_z = 1.8;

    //float step = 0.01;

// Datos de miros posicion deseada
    void pos_lineal_x_desCallback(const std_msgs::Float64::ConstPtr& pos_lineal_x_des)
{
    x_des = pos_lineal_x_des->data;
}
    void pos_lineal_y_desCallback(const std_msgs::Float64::ConstPtr& pos_lineal_y_des)
{
    y_des = pos_lineal_y_des->data;
}
    void pos_lineal_z_desCallback(const std_msgs::Float64::ConstPtr& pos_lineal_z_des)
{
    z_des = pos_lineal_z_des->data;
}

// Datos de miros velocidad deseada
    void vel_lineal_x_desCallback(const std_msgs::Float64::ConstPtr& vel_lineal_x_des)
{
    x_vel_des = vel_lineal_x_des->data;
}
    void vel_lineal_y_desCallback(const std_msgs::Float64::ConstPtr& vel_lineal_y_des)
{
    y_vel_des = vel_lineal_y_des->data;
}
    void vel_lineal_z_desCallback(const std_msgs::Float64::ConstPtr& vel_lineal_z_des)
{
    z_vel_des = vel_lineal_z_des->data;
}

// Datos de Gera posicion actual
    void pose_dronCallback(const geometry_msgs::Twist::ConstPtr& pose_dron)
{  
    x = pose_dron->linear.x;
    y = pose_dron->linear.y;
    z = pose_dron->linear.z;
    phi = pose_dron->angular.x;
    theta = pose_dron->angular.y; //pitch 
    psi = pose_dron->angular.z; //yaw
}

// Datos de Gera velocidad actual
    void velocidad_dronCallback(const geometry_msgs::Twist::ConstPtr& velocidad_dron)
{  
    x_vel = velocidad_dron->linear.x;
    y_vel = velocidad_dron->linear.y;
    z_vel = velocidad_dron->linear.z;
}

int main(int argc, char **argv)
{
    // Inicializar ROS y la creación del nodo
    ros::init(argc, argv, "control_posicion");
    ros::NodeHandle nh;
    
    // Datos de Gera
    ros::Subscriber pos_lineal = nh.subscribe("/pose_dron", 10, &pose_dronCallback);
    ros::Subscriber vel_lineal = nh.subscribe("/velocidad_dron", 10, &velocidad_dronCallback);

    // Datos de miros
    ros::Subscriber pos_lineal_des_x = nh.subscribe("/x_des", 10, &pos_lineal_x_desCallback);
    ros::Subscriber pos_lineal_des_y = nh.subscribe("/y_des", 10, &pos_lineal_y_desCallback);
    ros::Subscriber pos_lineal_des_z = nh.subscribe("/z_des", 10, &pos_lineal_z_desCallback);
    // ros::Subscriber pos_lineal_des = nh.subscribe("/pos_lineal_des", 10, &pos_lineal_desCallback);
    ros::Subscriber vel_lineal_des_x = nh.subscribe("/vel_lineal_des_x", 10, &vel_lineal_x_desCallback);
    ros::Subscriber vel_lineal_des_y = nh.subscribe("/vel_lineal_des_y", 10, &vel_lineal_y_desCallback);
    ros::Subscriber vel_lineal_des_z = nh.subscribe("/vel_lineal_des_z", 10, &vel_lineal_z_desCallback);

    ros::Publisher Th_pub = nh.advertise<std_msgs::Float64>("/Th", 10);
    ros::Publisher roll_des_pub = nh.advertise<std_msgs::Float64>("/roll_des", 10);
    ros::Publisher pitch_des_pub = nh.advertise<std_msgs::Float64>("/pitch_des", 10);
    ros::Publisher error_pos_pub = nh.advertise<geometry_msgs::Vector3>("error_pos",10);
    ros::Publisher error_vel_pub = nh.advertise<geometry_msgs::Vector3>("error_vel",10);

    ros::Rate loop_rate(100); 

    geometry_msgs::Vector3 error_pos;
    geometry_msgs::Vector3 error_vel;
    std_msgs::Float64 pitch_des_var;
    std_msgs::Float64 roll_des_var;
    std_msgs::Float64 Th_var;

    Eigen::Vector3d pos_lineal_var;
    Eigen::Vector3d vel_lineal_var;
    Eigen::Vector3d pos_lineal_des_var;
    Eigen::Vector3d vel_lineal_des_var;

    float s_phi = sin(phi);
    float c_phi = cos(phi);
    float s_psi = sin(psi);
    float c_psi = cos(psi);
    float s_theta = sin(theta);
    float c_theta = cos(theta);

    //Eigen::Vector3d pos_lineal_transp = pos_lineal.transpose();
    //Eigen::Vector3d vel_lineal_transp = vel_lineal.transpose();

    //Eigen::Vector3d pos_lineal_transp_des = pos_lineal_des.transpose();
    //Eigen::Vector3d vel_lineal_transp_des = vel_lineal_des.transpose();


    while(ros::ok())
    {
        // float arg_phi, arg_theta;

        if (Th > 0)
            Th = 0;
        if (Th < -30)
            Th = -30;

        float error_x = x - x_des;
        float error_y = y - y_des;
        float error_z = z - z_des;

        float error_x_vel = x_vel - x_vel_des;
        float error_y_vel = y_vel - y_vel_des;
        float error_z_vel = z_vel - z_vel_des;

        float uvx = (-kp_x * error_x) - (kd_x * error_x_vel);
        float uvy = (-kp_y * error_y) - (kd_y * error_y_vel);;
        float uvz = (-kp_z * error_z) - (kd_z * error_z_vel);;

        // float Th = ((m/(c_phi * c_theta)) * (z_dotdot) * (- g + uvz));
        float Th = ((m/(c_phi * c_theta)) * (- g + uvz));
        float roll_des = asin((m/Th) * ((s_psi * uvx) - (c_psi * uvy)));
        float pitch_des = asin((((m/Th) * uvx) - (s_psi * s_phi)) / (c_psi * c_phi));

        error_pos.x = error_x;
        error_pos.y = error_y;
        error_pos.z = error_z;

        error_vel.x = error_x_vel;
        error_vel.y = error_y_vel;
        error_vel.z = error_z_vel;

        roll_des_var.data = roll_des;
        pitch_des_var.data = pitch_des;
        Th_var.data = Th;

        roll_des_pub.publish(roll_des_var);
        pitch_des_pub.publish(pitch_des_var);
        Th_pub.publish(Th_var);

        error_pos_pub.publish(error_pos);
        error_vel_pub.publish(error_vel);
        
        ROS_INFO_STREAM("Error de posicion: " << error_pos.x << ", " << error_pos.y << ", " << error_pos.z);
        ROS_INFO_STREAM("Error de velocidad: " << error_vel.x << ", " << error_vel.y << ", " << error_vel.z);
        ROS_INFO_STREAM("Roll deseado: " << roll_des);
        ROS_INFO_STREAM("Pitch deseado: " << pitch_des);
        ROS_INFO_STREAM("Thrust deseado: " << Th);

        loop_rate.sleep();
    }

    return 0;
}