#!/usr/bin/env python3
import rospy
from std_msgs.msg import Float64  # Asumiendo que tus variables son de tipo float
import math

def publicar_variables():
    rospy.init_node('referencias')
    rate=rospy.Rate(100)

    step = .01

    x_des = -5
    y_des = 0
    z_des = 0
    yaw_des = 0

    x_vel_des = 0
    y_vel_des = 0
    z_vel_des = 0
    yaw_vel_des = 0

    pub_x = rospy.Publisher('/x_des', Float64, queue_size=10)
    pub_y = rospy.Publisher('/y_des', Float64, queue_size=10)
    pub_z = rospy.Publisher('/z_des', Float64, queue_size=10)
    pub_yaw = rospy.Publisher('/yaw_des', Float64, queue_size=10)

    pub_x_vel = rospy.Publisher('/x_vel_des', Float64, queue_size=10)
    pub_y_vel = rospy.Publisher('/y_vel_des', Float64, queue_size=10)
    pub_z_vel = rospy.Publisher('/z_vel_des', Float64, queue_size=10)
    pub_yaw_vel = rospy.Publisher('/yaw_vel_des', Float64, queue_size=10)

    init_time=rospy.get_time()

    while not rospy.is_shutdown():
        # t = rospy.get_time() - init_time
        t = 0.01+t
        print(t)
        if t < 30:
            x_vel_des = 0
            y_vel_des = 0
            z_vel_des = -0.1
            yaw_vel_des = 0

        if t >= 30:
            x_vel_des = 0.5 * math.sin(0.1*(t-5))
            y_vel_des = 0.5 * math.cos(0.1*(t-5))
            z_vel_des = 0
            yaw_vel_des = 0.1

        x_des = x_des + step * x_vel_des
        y_des = y_des + step * y_vel_des
        z_des = z_des + step * z_vel_des
        yaw_des = yaw_des + step * yaw_vel_des

        pub_x.publish(x_des)
        pub_y.publish(y_des)
        pub_z.publish(z_des)
        pub_yaw.publish(yaw_des)

        pub_x_vel.publish(x_vel_des)
        pub_y_vel.publish(y_vel_des)
        pub_z_vel.publish(z_vel_des)
        pub_yaw_vel.publish(yaw_vel_des)

        rate.sleep()

if __name__ == '_main_':
    try:
        publicar_variables()
    except rospy.ROSInterruptException:
        pass