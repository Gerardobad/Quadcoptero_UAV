// Header files que llaman a las librerías de C++, ROS y ROS Messages.
#include <ros/ros.h> 
#include <std_msgs/String.h>
#include <std_msgs/Float64.h>
#include <std_msgs/UInt64.h>
#include <string>
#include <cmath>
#include <iostream>
#include <Eigen/Dense>
#include <geometry_msgs/Twist.h>
#include <Eigen/Geometry>


float thrust;
float torque_roll, torque_pitch, torque_yaw;  
float f, m, g, step; 
float yaw, pitch, roll;
float v_dot, w_dot; 
float attitude_dot, attitude; 
float v, p, p_dot;

 void ThCallback(const std_msgs::Float64::ConstPtr& Th)
{
    thrust = Th->data;
}
 void torque_rollCallback(const std_msgs::Float64::ConstPtr& torque_roll_val)
{
    torque_roll = torque_roll_val->data;
}
 void torque_pitchCallback(const std_msgs::Float64::ConstPtr& torque_pitch_val)
{
    torque_pitch = torque_pitch_val->data;
}
 void torque_jawCallback(const std_msgs::Float64::ConstPtr& torque_jaw_val)
{
    torque_yaw = torque_jaw_val->data;
}

int main(int argc, char **argv)
{
    // Inicializar ROS y la creación del nodo
    ros::init(argc, argv, "dinamica"); // ros::init(argc, argv, "$<NOMBRE DEL ARCHIVO CPP>")
    ros::NodeHandle nh;
    
    // Declaración de los publishers
    //ros::Publisher <$PUBLISHER_NAME> = nh.advertise<$TIPO_DE_MENSAJE>("<$TÓPICO>", 
    ros::Publisher pose_pub = nh.advertise<geometry_msgs::Twist>("/pose_dron", 10); 
    ros::Publisher velocidad_pub = nh.advertise<geometry_msgs::Twist>("/velocidad_dron", 10); 

    ros::Subscriber Th_sub = nh.subscribe("/Th", 10, &ThCallback);
    ros::Subscriber torque_roll_sub = nh.subscribe("/torque_roll", 10, &torque_rollCallback);
    ros::Subscriber torque_pitch_sub = nh.subscribe("/torque_pitch", 10, &torque_pitchCallback);
    ros::Subscriber torque_jaw_sub = nh.subscribe("/torque_jaw", 10, &torque_jawCallback);

    // Frecuencia a la que correrá el nodo en Hz
    ros::Rate loop_rate(100);    // ros::Rate <$NOMBRE DE LA VARIABLE>($<Hz>)

    // Definición de las variables que identifican al mensaje de ROS
    geometry_msgs::Twist pose_dron;
    geometry_msgs::Twist velo_dron;

    // Con rosmsg show turtlesim/Pose podemos ver el tipo de mensaje que se manda 

    // Valores extraidos de otro nodo 
    // Thrust
    // torque_roll
    //torque_pitch 
    //torque_yaw  = 10; 

    // Valores del dron
    m = 2; // masa del dron
    g = 9.81; // valor de la gravedad
    step = 0.01;
    // thrust = -19.32; 
    // pose_dron.linear.x = -5;
    
    //Valores conocidos 
    Eigen::MatrixXf e3(1,3);
    e3 << 0, 0, 1; 
    e3 = e3.transpose();

    Eigen::MatrixXf v(1,3);
    v << 1, 1, 1; 
    v = v.transpose();

    Eigen::MatrixXf w(1,3);
    w << 1, 1, 1; 
    w = w.transpose();
    
    yaw = 1;
    roll = 1;
    pitch = 1;

    Eigen::Matrix3f R;  //Body frame to inertial frame rotation matrix
    R << cos(yaw)*cos(pitch), (cos(yaw)*sin(roll)*sin(pitch))-cos(roll)*sin(yaw), (sin(yaw)*sin(roll))+(cos(yaw)*cos(roll)*sin(pitch)),
        cos(pitch)*sin(yaw), (cos(yaw)*cos(roll))+(sin(yaw)*sin(roll)*sin(pitch)), (cos(roll)*sin(yaw)*sin(pitch))-(cos(yaw)*sin(roll)),
        -sin(pitch), cos(pitch)*sin(roll), cos(roll)*cos(pitch);

    Eigen::Matrix3f wx;
    wx << 0,-w(2),w(1),
        w(2), 0, -w(0),
        -w(1), w(0), 0;


    Eigen::Matrix3f J;
    J << 0.0411, 0 , 0, 
        0, 0.0478, 0, 
        0, 0, 0.0599;

    Eigen::MatrixXf torque(1,3); 
    torque(0) = torque_roll;
    torque(1) = torque_pitch;
    torque(2) = torque_yaw;
    torque = torque.transpose(); //Siempre es transpuesta

    Eigen::Matrix3f R2;  //Body frame to inertial frame rotation matrix
    R2 << 1,sin(roll)*tan(pitch), cos(roll)*tan(pitch),
        0, cos(roll), -sin(roll), 
        0, (sin(roll)/cos(pitch)), (cos(roll)/sin(pitch)); 


    while(ros::ok())
    {   
        // Angular
        Eigen::MatrixXf w_dot(3,1);
        w_dot = (J.inverse())*(torque - wx*J*w);

        w = w + step*w_dot; 
        
        Eigen::MatrixXf attitude_dot(3,1);
        attitude_dot = R2 * w;

        Eigen::MatrixXf attitude(3,1);
        attitude = attitude + step*attitude_dot; 

        // Lineal
        Eigen::MatrixXf f(3,1);
        f = (thrust*e3) + (R.inverse()*(m*g*e3)); //La delta se ignora pues no tendremos en cuenta las perturbaciones externas
        
        Eigen::MatrixXf v_dot(3,1);
        v_dot = (f/m) - wx*v;

        v = v + step*v_dot;

        Eigen::MatrixXf p_dot(3,1);
        p_dot = R * v;

        Eigen::MatrixXf p(3,1);
        p = p + step*p_dot;

        pose_dron.linear.x = p(0);  // x
        pose_dron.linear.y = p(1);  // y
        pose_dron.linear.z = p(2);  // z

        pose_dron.angular.x = attitude(0);   // roll
        pose_dron.angular.y = attitude(1);   // pitch
        pose_dron.angular.z = attitude(2);   // yaw
 
        velo_dron.linear.x = p_dot(0);      // x velocidad 
        velo_dron.linear.y = p_dot(1);      // y velocidad
        velo_dron.linear.z = p_dot(2);      // z velocidad

        velo_dron.angular.x = attitude_dot(0);  // roll velocidad
        velo_dron.angular.y = attitude_dot(1);  // pitch velocidad
        velo_dron.angular.z = attitude_dot(2);  // yaw velocidad

        pose_pub.publish(pose_dron);
        velocidad_pub.publish(velo_dron);

        ros::spinOnce();
        loop_rate.sleep();
        // std::cout << attitude << std::endl;

        yaw = attitude(2);
        pitch = attitude(1);
        roll = attitude(0);

        Eigen::Matrix3f R;  //Body frame to inertial frame rotation matrix
        R << cos(yaw)*cos(pitch), (cos(yaw)*sin(roll)*sin(pitch))-cos(roll)*sin(yaw), (sin(yaw)*sin(roll))+(cos(yaw)*cos(roll)*sin(pitch)),
         cos(pitch)*sin(yaw), (cos(yaw)*cos(roll))+(sin(yaw)*sin(roll)*sin(pitch)), (cos(roll)*sin(yaw)*sin(pitch))-(cos(yaw)*sin(roll)),
            -sin(pitch), cos(pitch)*sin(roll), cos(roll)*cos(pitch);

         Eigen::Matrix3f wx;
        wx << 0,-w(2),w(1),
            w(2), 0, -w(0),
            -w(1), w(0), 0;

        Eigen::Matrix3f R2;  //Body frame to inertial frame rotation matrix
        R2 << 1,sin(roll)*tan(pitch), cos(roll)*tan(pitch),
         0, cos(roll), -sin(roll), 
            0, (sin(roll)/cos(pitch)), (cos(roll)/sin(pitch)); 

    }
    return 0;
}