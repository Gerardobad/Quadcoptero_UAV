#include <ros/ros.h>
#include <std_msgs/String.h>
#include <std_msgs/Float64.h>
#include <std_msgs/UInt64.h>
#include <geometry_msgs/Vector3.h>
#include <vector>
#include <iostream>
#include <cmath>
#include <string>
#include <eigen3/Eigen/Dense>
#include <geometry_msgs/Twist.h>

//Declaracion de Variables para Torque
float angular_pitch_des = 0.0;
float angular_roll_des = 0.0;
float jaw_des = 0.0;
float Jxx = 0.0411;
float Jyy = 0.0478;
float Jzz = 0.0599;

//Declaracion de Variables para Errores
float error_roll = 0.0;
float error_pitch = 0.0;
float error_jaw = 0.0;
float error_jaw_dot = 0.0;
float error_roll_dot = 0.0;
float error_pitch_dot = 0.0;

//Declaracion de Variables de Control
float Kp_roll = 0.6;
float Kp_pitch = 0.6;
float Kp_jaw = 0.5;

float Kd_roll = 1;
float Kd_pitch = 1;
float Kd_jaw = 1;

//Declaracion de Controles
float u_roll = 0.0;
float u_pitch = 0.0;
float u_jaw = 0.0;

//Declaracion de Torques
float torque_roll = 0.0;
float torque_pitch = 0.0;
float torque_jaw = 0.0;

float roll_des,pitch_des, angular_jaw_des,roll, pitch, jaw, roll_dot, pitch_dot, jaw_dot; 

void VariablesLinealRollCallback(const std_msgs::Float64::ConstPtr& roll_des_var) //Callback Eli
{
    roll_des= roll_des_var -> data; //me envia ELi
}
void VariablesLinealPitchCallback(const std_msgs::Float64::ConstPtr& pitch_des_var) //Callback Eli
{
    pitch_des= pitch_des_var -> data; //me envia Eli
}
void VariablesReferenciasCallback(const std_msgs::Float64::ConstPtr& var_lista_referencias) //Callback Miros no estoy seguro de la lista pero la nombre asi
{
    angular_jaw_des= var_lista_referencias -> data; //me envia Miros de Referencias
}
void VariablesDinamicaPoseCallback(const geometry_msgs::Twist::ConstPtr& pose_dron) //Callback Gerardo
{
    roll= pose_dron -> angular.x; //me envia Gerardo
    pitch= pose_dron-> angular.y; //me envia Gerardo
    jaw= pose_dron -> angular.z; //me envia Gerardo
}
void VariablesDinamicaVeloCallback(const geometry_msgs::Twist::ConstPtr& velocidad_dron) //Callback Gerardo
{
    roll_dot= velocidad_dron -> angular.x; //me envia Gerardo
    pitch_dot= velocidad_dron -> angular.y; //me envia Gerardo
    jaw_dot= velocidad_dron -> angular.z; //me envia Gerardo
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "control_angular"); // ros::init(argc, argv, "$<NOMBRE DEL ARCHIVO CPP>")
    ros::NodeHandle nh; //ros::NodeHandle $NOMBRE_DE_LA_VARIABLE_QUE_REPRESENTA_AL_NODO_EN_EL_CÓDIGO>
    
    //Subscriber
    ros::Subscriber var_lista_referencias_sub = nh.subscribe("/angular_jaw_des", 10, &VariablesReferenciasCallback);
    ros::Subscriber roll_des_var_sub = nh.subscribe("/roll_des", 10, &VariablesLinealRollCallback);
    ros::Subscriber pitch_des_var_sub = nh.subscribe("/pitch_des", 10, &VariablesLinealPitchCallback);
    
    // Datos Gera posicion angular
    ros::Subscriber pose_dron_sub = nh.subscribe("/pose_dron", 10, &VariablesDinamicaPoseCallback);
    // Datos Gera velocidad angular
    ros::Subscriber velo_dron_sub = nh.subscribe("/velocidad_dron", 10, &VariablesDinamicaVeloCallback);
    
    //Publisher
    ros::Publisher torque_roll_pub = nh.advertise<std_msgs::Float64>("/torque_roll", 10);
    ros::Publisher torque_pitch_pub = nh.advertise<std_msgs::Float64>("/torque_pitch", 10); 
    ros::Publisher torque_jaw_pub = nh.advertise<std_msgs::Float64>("/torque_jaw", 10);

    // Frecuencia a la que correrá el nodo en Hz
    ros::Rate loop_rate(100);    // ros::Rate <$NOMBRE DE LA VARIABLE>($<Hz>)

    std_msgs::Float64 torque_roll_var; //Juan publica
    std_msgs::Float64 torque_pitch_var; //Juan publica
    std_msgs::Float64 torque_jaw_var; //Juan publica

    while(ros::ok())
    {
        //Calculo de Errores de Posicion
        error_roll= roll - roll_des;
        error_pitch= pitch - pitch_des;
        error_jaw= jaw - jaw_des;

         //Calculo de Errores de Posicion
        error_roll_dot= roll_dot - angular_roll_des;
        error_pitch_dot= pitch_dot- angular_pitch_des;
        error_jaw_dot= jaw_dot- 0.1;

        //Control PD
        u_roll = (Kp_roll*error_roll) +(Kd_roll*error_roll_dot);
        u_pitch = (Kp_pitch*error_pitch) +(Kd_roll*error_pitch_dot);
        u_jaw = (Kp_jaw*error_jaw) +(Kd_jaw*error_jaw_dot);

        // u_roll = -(Kp_roll*error_roll) -(Kd_roll*error_roll_dot);
        // u_pitch = -(Kp_pitch*error_pitch) -(Kd_roll*error_pitch_dot);
        // u_jaw = -(Kp_jaw*error_jaw) -(Kd_jaw*error_jaw_dot);

        //Calculo de Torques
        // torque_roll_var.data = Jxx*(((Jzz-Jyy)/Jxx)*pitch_dot*jaw_dot +u_roll);
        // torque_pitch_var.data = Jyy*(((Jxx-Jzz)/Jyy)*roll_dot*jaw_dot +u_pitch);
        // torque_jaw_var.data = Jzz*(((Jyy-Jxx)/Jzz)*roll_dot*pitch_dot +u_jaw);
        torque_roll_var.data = Jxx*u_roll;
        torque_pitch_var.data = Jyy*u_pitch;
        torque_jaw_var.data = Jzz*u_jaw;
        std::cout << "Torque 1: " << torque_roll << "Torque 2: " << torque_pitch << "Torque 3: " << torque_jaw << std::endl;

        torque_roll_pub.publish(torque_roll_var);
        torque_pitch_pub.publish(torque_pitch_var);
        torque_jaw_pub.publish(torque_jaw_var);

        ros::spinOnce();
        loop_rate.sleep();
    }

}